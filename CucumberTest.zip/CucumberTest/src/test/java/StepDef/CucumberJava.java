package StepDef;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.annotation.en.Given;
import cucumber.annotation.en.Then;
import cucumber.annotation.en.When;
import junit.framework.Assert;

public class CucumberJava {

	public static WebDriver driver = null;

	@Given("^I have open the browser$")
	public void openBrowser() {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\SaikiranGosika\\Downloads\\chromedriver_win32\\chromedriver.exe");

		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}

	@Given("^the user launched the \"([^\"]*)\"$")
	public void the_user_launched_the(String arg1) throws InterruptedException {
		driver.get(arg1);
		Thread.sleep(10000);

	}

	@Then("^user login using \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_login_using_admin_and_admin_(String username, String password) {
		driver.findElement(By.id("login")).sendKeys(username);
		driver.findElement(By.id("password")).sendKeys(password);
		driver.findElement(By.id("form-login_submitAuth")).click();

	}
	
	@Then("^Click on Administrator link$")
	public void Click_on_Administrator_link() {
		driver.findElement(By.xpath("//*[contains(text(),'Administration')]")).click();   
	}

	@Then("^Click on add a user link$")
	public void Click_on_add_a_user_link() {
		
		driver.findElement(By.xpath("//*[contains(text(),'Add a user')]")).click();     
	    
	}
	@Then("^enter \"([^\"]*)\" and \"([^\"]*)\" in the firstname and lastname$")
	public void enter_and_in_the_firstname_and_lastname(String arg1, String arg2) {
		driver.findElement(By.id("firstname")).sendKeys(arg1);
		driver.findElement(By.id("lastname")).sendKeys(arg2);
	    
	}

	@Then("^enter the email and phonenumber as \"([^\"]*)\" and \"([^\"]*)\"$")
	public void enter_the_email_and_phonenumber_as_and(String arg1, String arg2) {
		driver.findElement(By.id("email")).sendKeys(arg1);
		driver.findElement(By.id("phone")).sendKeys(arg2);
	    
	}

	@Then("^enter valid login credential \"([^\"]*)\"$")
	public void enter_valid_login_credential(String arg1) {
		
		driver.findElement(By.id("username")).sendKeys(arg1);
	    
	}

	@Then("^Click on radio buttion for password$")
	public void Click_on_radio_buttion_for_password() {
	    
		driver.findElement(By.id("qf_64d726")).click(); 
	}

	@Then("^enter valid password \"([^\"]*)\"$")
	public void enter_valid_password(String arg1) {
		driver.findElement(By.id("password")).sendKeys(arg1);
	    
	}

	@Then("^Select Valid credentials from profile list box as Trainer$")
	public void Select_Valid_credentials_from_profile_list_box_as_Trainer() {
	    Select s = new Select(driver.findElement(By.id("status_select")));
	    s.selectByVisibleText("Trainer");
	    
	}

	@Then("^click on add button$")
	public void click_on_add_button() {
		driver.findElement(By.xpath("//*[@name='submit']")).click(); 
	    
	}

	@Then("^click on user list and check the user \"([^\"]*)\"$")
	public void click_on_user_list_and_check_the_user(String arg1) {
		driver.findElement(By.id("search_simple_keyword")).sendKeys(arg1);
		driver.findElement(By.id("search_simple_submit")).click();
		
		String s = driver.findElement(By.xpath("//*/tbody/tr[2]/td[6]")).getText();
		Assert.assertEquals("The user is verified", s, arg1);
	}

	
}
